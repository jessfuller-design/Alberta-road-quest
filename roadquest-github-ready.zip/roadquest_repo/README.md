# Andy's Alberta Road Quest

A simple offline study app based on the **Spring 2026 Alberta Driver's Guide**. It is designed for phone and laptop use and stores progress locally on the device.

## Play now

Open `index.html` in a browser. No server is required for laptop use.

For a phone-style installed app, publish the repository with GitHub Pages, open it once while online, and use **Add to Home Screen**. The service worker then caches the app for offline use.

## Current content

- 377 questions with permanent IDs
- Unlimited quick play and custom quizzes
- Mock tests, endless mode and flashcards
- Missed-question and saved-question review
- Topic mastery and local progress
- Passenger-only Road Trip Spotter

This is independent study practice and is not an official Government of Alberta test.

## Repository structure

```text
index.html
manifest.webmanifest
sw.js
data/
  questions.json       # master database
  questions.js         # browser-loadable copy
  pack-*.json           # incremental content packs
scripts/
  build-question-db.js
  validate-questions.js
.github/workflows/
  validate.yml
```

## Add a question pack

Create a new `data/pack-*.json` file using unused permanent IDs, then run:

```bash
npm run check
```

The build script merges packs into `questions.json` and regenerates `questions.js`. The validator checks IDs, required fields, answer counts and duplicate question text.

## GitHub Pages

In the repository, open **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
